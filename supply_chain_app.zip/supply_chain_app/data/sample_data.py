"""
Sample data — realistic FMCG supply chain demo
3 manufacturing plants → 4 warehouses → 6 demand points
"""

from core.graph_engine import SupplyChainGraph, Node, Edge


def load_demo_data() -> SupplyChainGraph:
    sc = SupplyChainGraph()

    # ── Manufacturing plants ───────────────────
    sc.add_node(Node("P1", "Plant Mumbai",   "plant", capacity=500, location="Mumbai, India",    x=0, y=2))
    sc.add_node(Node("P2", "Plant Chennai",  "plant", capacity=400, location="Chennai, India",   x=0, y=0))
    sc.add_node(Node("P3", "Plant Pune",     "plant", capacity=350, location="Pune, India",      x=0, y=-2))

    # ── Warehouses ────────────────────────────
    sc.add_node(Node("W1", "WH North",   "warehouse", capacity=400, location="Delhi, India",     x=1, y=2.5))
    sc.add_node(Node("W2", "WH West",    "warehouse", capacity=350, location="Ahmedabad, India", x=1, y=0.8))
    sc.add_node(Node("W3", "WH East",    "warehouse", capacity=300, location="Kolkata, India",   x=1, y=-0.8))
    sc.add_node(Node("W4", "WH South",   "warehouse", capacity=280, location="Bangalore, India", x=1, y=-2.5))

    # ── Demand points ─────────────────────────
    sc.add_node(Node("D1", "Delhi Market",     "demand", capacity=200, location="Delhi, India"))
    sc.add_node(Node("D2", "Jaipur Market",    "demand", capacity=120, location="Jaipur, India"))
    sc.add_node(Node("D3", "Surat Market",     "demand", capacity=180, location="Surat, India"))
    sc.add_node(Node("D4", "Bhubaneswar Mkt",  "demand", capacity=100, location="Bhubaneswar, India"))
    sc.add_node(Node("D5", "Hyderabad Market", "demand", capacity=160, location="Hyderabad, India"))
    sc.add_node(Node("D6", "Kochi Market",     "demand", capacity=140, location="Kochi, India"))

    # ── Plant → Warehouse edges ───────────────
    sc.add_edge(Edge("P1", "W1", capacity=300, cost=2.0))
    sc.add_edge(Edge("P1", "W2", capacity=250, cost=1.5))
    sc.add_edge(Edge("P2", "W3", capacity=200, cost=1.8))
    sc.add_edge(Edge("P2", "W4", capacity=220, cost=2.2))
    sc.add_edge(Edge("P3", "W2", capacity=180, cost=1.2))
    sc.add_edge(Edge("P3", "W4", capacity=200, cost=1.6))
    sc.add_edge(Edge("P1", "W3", capacity=150, cost=3.0))   # cross-link (redundancy)
    sc.add_edge(Edge("P2", "W1", capacity=100, cost=3.5))   # cross-link

    # ── Warehouse → Demand edges ──────────────
    sc.add_edge(Edge("W1", "D1", capacity=220, cost=1.0))
    sc.add_edge(Edge("W1", "D2", capacity=150, cost=1.5))
    sc.add_edge(Edge("W2", "D2", capacity=130, cost=1.2))
    sc.add_edge(Edge("W2", "D3", capacity=200, cost=1.0))
    sc.add_edge(Edge("W3", "D4", capacity=120, cost=1.0))
    sc.add_edge(Edge("W3", "D5", capacity=130, cost=1.8))
    sc.add_edge(Edge("W4", "D5", capacity=180, cost=1.0))
    sc.add_edge(Edge("W4", "D6", capacity=160, cost=1.2))
    sc.add_edge(Edge("W1", "D4", capacity=80,  cost=2.5))   # backup route
    sc.add_edge(Edge("W2", "D6", capacity=90,  cost=2.0))   # backup route

    return sc
